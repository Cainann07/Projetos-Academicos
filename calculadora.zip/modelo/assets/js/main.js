const inputVisor = document.querySelector('#visor')
const btnUm = document.querySelector('.um')
const btnDois = document.querySelector('.dois')
const btnTres = document.querySelector('.tres')
const btnQuatro = document.querySelector('.quatro')
const btnCinco = document.querySelector('.cinco')
const btnSeis = document.querySelector('.seis')
const btnSete = document.querySelector('.sete')
const btnOito = document.querySelector('.oito')
const btnNove = document.querySelector('.nove')
const btnZero = document.querySelector('.zero')
const btnDuasCasas = document.querySelector('.duas-casas')
const btnPonto = document.querySelector('.ponto')
const botaoLimpar = document.querySelector('.on');
const botaoApagar = document.querySelector('.c')

const btnPorcentagem = document.querySelector('.porcentagem')
const btnGt = document.querySelector('.gt')
const btnMultiplica = document.querySelector('.multiplicar')
const btnDivide = document.querySelector('.dividir')
const btnSoma = document.querySelector('.soma')
const btnSubtracao = document.querySelector('.subtracao')
const btnResultado = document.querySelector('.resultado')

const teclas = document.querySelector('.teclas')

let valores = []

botaoLimpar.addEventListener('click', function(){
    inputVisor.value = ""
    valores = []
})

botaoApagar.addEventListener('click', function(){
    inputVisor.value = inputVisor.value.slice(0, -1)
})

btnUm.addEventListener('click', function(){
    inputVisor.value += 1;
})

btnDois.addEventListener('click', function(){
    inputVisor.value += 2;
})

btnTres.addEventListener('click', function(){
    inputVisor.value += 3;
})

btnQuatro.addEventListener('click', function(){
    inputVisor.value += 4;
})

btnCinco.addEventListener('click', function(){
    inputVisor.value += 5;
})

btnSeis.addEventListener('click', function(){
    inputVisor.value += 6;
})

btnSete.addEventListener('click', function(){
    inputVisor.value += 7;
})

btnOito.addEventListener('click', function(){
    inputVisor.value += 8;
})

btnNove.addEventListener('click', function(){
    inputVisor.value += 9;
})

btnZero.addEventListener('click', function(){
    inputVisor.value += 0;
})

btnDuasCasas.addEventListener('click', function(){
    inputVisor.value += '00';
})

btnPonto.addEventListener('click', function(){
    inputVisor.value += ".";
})

btnPorcentagem.addEventListener('click', function(){
    inputVisor.value = inputVisor.value/100
})

btnGt.addEventListener('click', function(){
    const soma = valores.reduce((acc, valor) => acc + valor, 0)
    inputVisor.value = soma
})

btnMultiplica.addEventListener('click', function(){
    inputVisor.value += '*' 
})

btnDivide.addEventListener('click', function(){
    inputVisor.value += '/'
})

btnSoma.addEventListener('click', function(){
    inputVisor.value += '+'
})

btnSubtracao.addEventListener('click', function(){
    inputVisor.value += '-'
})

btnResultado.addEventListener('click', function(){
    const expressao = inputVisor.value
    const resultado = eval(expressao)
    valores.push(resultado)

    inputVisor.value = resultado
})